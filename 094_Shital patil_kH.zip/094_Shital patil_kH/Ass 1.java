//Que 1-Write a program to print Hello World. Compile and run it using command prompt.
Program-
class H1
{
public static void main(String[] args)
  {
   System.out.println("Hello World!!!");
  }
}

o/p-Hello World!!!



//Q2-Write a program to declare a variable named rollNo of integer type. Assign it 
a value (let say 100) to it and print the following statement roll no = 100 .
import java.util.Scanner;
class Rollno
{
public static void main(String args[])
{
int rollno;
System.out.println("enter roll no=");
Scanner sc= new Scanner(System.in);
rollno=sc.nextInt();
System.out.println("Roll no="+rollno);

}
}
o/p-
enter roll no=
10
Roll no=10



//Q3-Find the result of following expressions. You need to determine the primitive data type of the variable by looking carefully the given expression and initialize variables by any random value.
A. y = x2 + 3x - 7 (print value of y) 
B. y = x++ + ++x (print value of x and y) 
C. z = x++ - --y - --x  +  x++ (print value of x ,y and z)
D. z = x && y || !(x || y)  (print value of z) [ x, y, z are boolean variables ]


class Op1
{
public static void main(String[] args)
{
int y;
int x=10;
y=(x*x)+(3*x)-7;
System.out.println("value of y is"+y);

x=15;
y = x++ + ++x;
System.out.println("value of x is"+x);
System.out.println("value of y is"+y);

int z = x++ - --y - --x  +  x++; 
System.out.println("value of x is"+x);
System.out.println("value of y is"+y);
System.out.println("value of z is"+z);

expression();
}
static void expression()
{
boolean x=true;
boolean y=false;

boolean z = x && y || !(x || y) ;
System.out.println("value of z is"+z);

}
}
o/p-
value of y is123
value of x is17
value of y is32
value of x is18
value of y is31
value of z is-14
value of z isfalse



Q4-Write a program that initializes 2 byte type of variables. Add the values of these variables and store in a byte type of variable. 
[Note: primitive down casting is required in this program ] .




















//Q5-Write a program that takes user’s name as command line argument and prints Welcome <entered user name>.
 class cmd1
{
 public static void main(String args[])
{
 String s1=args[0];
 String s2=args[1];
System.out.println(s1);
System.out.println(s2);
}
}




//Q6-Write a program that takes radius of a circle as input. Read the entered radius using Scanner class. Then calculate and print the area and circumference of the circle

import java.util.Scanner;
class CircleDemo
{
   static Scanner sc = new Scanner(System.in);
   public static void main(String args[])
   {
      System.out.print("Enter the radius: ");
     
      double radius = sc.nextDouble();
      Area = PI*radius*radius
      double area = Math.PI * (radius * radius);
      System.out.println("The area of circle is: " + area);
      Circumference = 2*PI*radius
      double circumference= Math.PI * 2*radius;
      System.out.println( "The circumference of the circle is:"+circumference) ;
   }
}

o/p-Enter the radius: 1
The area of circle is: 3.141592653589793
The circumference of the circle is:6.283185307179586



//Q7-Write a program to calculate sum of 5 subject’s marks & find percentage. 
Take the obtained marks from user using Scanner class. Output should be in this format [ percentage marks = 99 % ]. Use concatenation operator here.


import java.util.Scanner;

public class Totalof5subjects2 {
	private static Scanner sc;
	public static void main(String[] args) 
	{
		int totalSubjects, i;
	    float Marks, total = 0, Percentage, Average;
		sc = new Scanner(System.in);
		
		System.out.print(" Please Enter the Total Number of Subjects : ");
		totalSubjects = sc.nextInt();
		
		System.out.print(" Please Enter the Subjects Marks : ");
		for(i = 0; i < totalSubjects; i++)
		{
			Marks = sc.nextInt();
			total = total + Marks;
		}
	
		Average = total / totalSubjects;
	    Percentage = (total / (totalSubjects * 100)) * 100;
	    
	    System.out.println(" Total Marks =  " + total);
	    System.out.println(" Average Marks =  " + Average);
	    System.out.println(" Marks Percentage =  " + Percentage);
	}
}





//Q8.	Write a program to find the simple interest. Take the principle amount, rate of interest and time from user using Scanner class.

import java.util.Scanner;
public class Simple_Interest
{
    public static void main(String args[]) 
    {
        float p, r, t;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the Principal : ");
        p = s.nextFloat();
        System.out.print("Enter the Rate of interest : ");
        r = s.nextFloat();
        System.out.print("Enter the Time period : ");
        t = s.nextFloat();
        float si;
        si = (r * t * p) / 100;
        System.out.print("The Simple Interest is : " + si);
    }
}

o/p-

Enter the Principal : 20202
Enter the Rate of interest : 2.5
Enter the Time period : 3
The Simple Interest is : 1515.15


//Q9-Write a program to read the days (eg. 670 days) as integer value using Scanner class. Now convert the entered days into complete years, months and days and print them


import java.util.Scanner;
public class Year_Week_Day 
{
    public static void main(String args[])
    {
        int m, year, week, day;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the number of days:");
        m = s.nextInt();
        year = m / 365;
        m = m % 365;
        System.out.println("No. of years:"+year);
        week = m / 7;
        m = m % 7;
        System.out.println("No. of weeks:"+week);
        day = m;
        System.out.println("No. of days:"+day);
    }
}

o/p-Enter the number of days:756
No. of years:2
No. of weeks:3
No. of days:5

//Q10-Write a program to convert temperature from Fahrenheit to Celsius. Take Fahrenheit as input using Scanner class. [ formula : C= 5*(f-32)/9 ]


import java.util.Scanner;
public class Exercise1 {

    public static void main(String[] Strings) {

        Scanner input = new Scanner(System.in);

        System.out.print("Input a degree in Fahrenheit: ");
        double fahrenheit = input.nextDouble();

        double  celsius =(( 5 *(fahrenheit - 32.0)) / 9.0);
        System.out.println(fahrenheit + " degree Fahrenheit is equal to " + celsius + " in Celsius");
    }
}

o/p-Input a degree in Fahrenheit: 212                                                                             
212.0 degree Fahrenheit is equal to 100.0 in Celsius 

//Q11-Write a program to swap two numbers without using third variable


class demo {  
 public static void main(string arg[]) {  
  System.out.println("Before swapping");  
  int x = 10;  
  int y = 20;  
  System.out.println("value of x:" + x);  
  System.out.println("value of y:" + y);  
  system.out.println("After swapping");  
  x = x + y;  
  y = x - y;  
  x = x - y;  
  System.out.println("value of x:" + x);  
  System.out.println("value of y:" + y);  
 }  
}


//Q12-In a company an employee is paid as under: If his basic salary is less than Rs. 10000, then HRA = 10% of basic salary and DA = 90% of basic salary. If his salary is either equal to or above Rs. 10000, then HRA = Rs. 2000 and DA = 98% of basic salary. 
If the employee's salary is input by the user write a program to find his gross salary. [ formula : GS= Basic + DA + HRA ]


//Q13-Program to find greatest in 3 numbers. [ once using if else statement and then using ternary operator ( logical operator) ]  

import java.util.Scanner;  
public class LargestNumberExample1  
{  
public static void main(String[] args)   
{  
int a, b, c, largest, temp;  
//object of the Scanner class  
Scanner sc = new Scanner(System.in);  
//reading input from the user  
System.out.println("Enter the first number:");  
a = sc.nextInt();  
System.out.println("Enter the second number:");  
b = sc.nextInt();  
System.out.println("Enter the third number:");  
c = sc.nextInt();  
 
temp=a>b?a:b;  

largest=c>temp?c:temp;  

System.out.println("The largest number is: "+largest);  
}  
}  

o/p-Enter the first number:
23
Enter the second number:
11
Enter the third number:
67
Largest Number is: 67


//Q14-Program to check that entered year is a leap year or not.

import java.util.Scanner;
public class Demo {

    public static void main(String[] args) {

    	int year;
    	Scanner scan = new Scanner(System.in);
    	System.out.println("Enter any Year:");
    	year = scan.nextInt();
    	scan.close();
        boolean isLeap = false;

        if(year % 4 == 0)
        {
            if( year % 100 == 0)
            {
                if ( year % 400 == 0)
                    isLeap = true;
                else
                    isLeap = false;
            }
            else
                isLeap = true;
        }
        else {
            isLeap = false;
        }

        if(isLeap==true)
            System.out.println(year + " is a Leap Year.");
        else
            System.out.println(year + " is not a Leap Year.");
    }
}
Output:Enter any Year: 
2001
2001 is not a Leap Year.


//Q15-Accept person’s gender (character m for male and f for female), age (integer), as input and then check whether person is eligible for marriage or not.

import java.util.Scanner;
class Person
{
public static void main(String[] args)
{
int age;
Scanner sc=new Scanner(System.in);
System.out.println("enter character");
char gender=sc.next().charAt(0);
System.out.println("enter age");
age=sc.nextInt();

if((gender=='M' & age>=18) || (gender=='f' & age>=18))
{
System.out.println("eligible for marraige");
}
else
{
System.out.println("not eligible for marraige");
}

}
}