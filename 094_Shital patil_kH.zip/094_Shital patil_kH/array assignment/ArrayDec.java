class  ArrayDec
{
   public static void main(String args[])
{
   int number[5];
   float avrage[4];
  double marks[3];

System.out.println("number ");
System.out.println("average ");
 System.out.println("marks ");
}
}
