class SearchArray
{
    public static void main(String args[])
{
   int [] value = {1,2,3,4,5};
  int index=0;
for(int i=0;i<value.length;i++)
{
   if(value[i]==3)
{
  index=i;
}
}
System.out.println("Index="+index);
}
}
