import java.util.Scanner;
class ArrayInput
{
   public static void main(String args[])
{
   int n;
Scanner sc= new Scanner(System.in);
System.out.print("Enter the no. of elements ");

n=sc.nextInt();

int[]array=new int[10];
System.out.print("Enter the no. of elements ");
for(int i=0;i<n;i++)
{
  array[i]=sc.nextInt();
}

System.out.print("Array elements ");

for(int i=0;i<n;i++)
{
  System.out.println(array[i]);
}
}
}
